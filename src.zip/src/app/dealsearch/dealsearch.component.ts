import { ContractDealDropDown } from '../_models/ContractDealDropDown';
import { StatusDropDown } from '../_models/StatusDropDown';
import { WelcomePackageDropDown } from '../_models/WelcomePackageDropDown';
import { SyndicationDropDown } from '../_models/SyndicationDropDown';
import { PartyDealDropDown } from '../_models/PartyDealDropDown';
import { SourceDropDown } from '../_models/SourceDropDown';
import { EntityDropDown } from '../_models/EntityDropDown';
import { DocumentSubtypeDropDown } from '../_models/DocumentSubtypeDropDown';
import { Component, OnInit } from '@angular/core';
import { DealsearchModel } from '../_models/DealsearchModel';
import { MetadataModel } from '../_models/MetadataModel';
import { SearchDetails } from '../_models';
import { SearchService, InvoiceService } from '../_services';
import { DealSearchDetails } from '../_models/DealSearchDetails';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';
import { Router, ActivatedRoute } from '@angular/router';
import { ActionsDropDown } from '../_models/actionsDropDown';

@Component({
  selector: 'app-dealsearch',
  templateUrl: './dealsearch.component.html',
  styleUrls: ['./dealsearch.component.css'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})
export class DealsearchComponent implements OnInit {

  status: DealsearchModel = new DealsearchModel();
  documentSubtype1: DocumentSubtypeDropDown[] = [
    { id: 0, name: 'Document Subtype 1' },
    { id: 1, name: 'Document Subtype 2' },
  ];

  status1: StatusDropDown[] = [
    { id: 0, name: 'Interim' },
    { id: 1, name: 'Final' },
  ];

  welcome1: WelcomePackageDropDown[] = [
    { id: 0, name: 'True' },
    { id: 1, name: 'False' },

  ];
  contract1: ContractDealDropDown[] = [
    { id: 0, name: 'Loan' },
    { id: 1, name: 'Lease' },
    { id: 2, name: 'Progress-Loan' },

  ];
  syndication1: SyndicationDropDown[] = [
    { id: 0, name: 'True' },
    { id: 1, name: 'False' },

  ];
  party1: PartyDealDropDown[] = [
    { id: 0, name: 'Customer' },
    { id: 1, name: 'Funder' },
    { id: 2, name: 'Vendor' },
  ];
  source1: SourceDropDown[] = [
    { id: 0, name: 'SalesForce' },
    { id: 1, name: 'LeaseWave' },
    { id: 2, name: 'Migration' },
    { id: 3, name: 'Alfresco' },
  ];
  entity1: EntityDropDown[] = [
    { id: 0, name: 'Party' },
    { id: 1, name: 'Accounts' },
    { id: 2, name: 'Opportunity' },
    { id: 3, name: 'LOC' },
    { id: 4, name: 'Contract' },
  ];
  action1: ActionsDropDown[] = [
    { id: 0, name: 'Mark as Final' },
  ]
  public searchData;
  dealSearch: DealsearchModel = new DealsearchModel();
  searchDetails: DealSearchDetails = new DealSearchDetails();

  constructor(private _invoiceService: InvoiceService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.dealSearch.partyNumber = this.activatedRoute.snapshot.queryParamMap.get('partyNumber');
    this.dealSearch.partyName = this.activatedRoute.snapshot.queryParamMap.get('partyName');
    this.dealSearch.sfdcOpportunityId = this.activatedRoute.snapshot.queryParamMap.get('opportunityId');
    this.dealSearch.lineOfCreditNumber = this.activatedRoute.snapshot.queryParamMap.get('creditNumber');
    this.dealSearch.lwContractSequenceNumber = this.activatedRoute.snapshot.queryParamMap.get('sequenceNumber');
    this.dealSearch.partyDealType = this.activatedRoute.snapshot.queryParamMap.get('partyDealType');
  }
  public getSearchData() {

    const partyNumber = this.dealSearch.partyNumber;
    this._invoiceService.searchIndustrialFinancialDeal(this.dealSearch).subscribe((data: Array<object>) => {
      this.searchData = data['metadataList'];
      console.log('entered');
      // console.log(data);
      // console.log(this.searchModel);
      console.log(this.searchData);

    });


  }
  myFunc() {
    const table = document.getElementsByTagName('tr');
    for (let i = 0; i < table.length; i++) {
      const checked = table[i].cells[0].childNodes[0] as HTMLInputElement;
      if (checked.checked === true) {
        alert(table[i].cells[2].innerText);
      }
    }
  }

  onSubmit() {
    console.log('search data started');
    console.log(this.dealSearch);
    // this.metadata =  this._searchService.metadataIntialization(this.metadata);
    this.searchData = this.getSearchData();
    console.log(this.dealSearch);
    console.log(this.searchData);
    console.log('search data finished');
    document.getElementById('actions').style.display = "inline";
    document.getElementById('displaytable').style.display = 'inline-table';
    return true;
  }


}

