import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NgModule } from '@angular/core';
import { OwlDateTimeModule, OwlNativeDateTimeModule, OWL_DATE_TIME_FORMATS} from 'ng-pick-datetime';
import { NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import { InvoiceService } from '../_services';
import { SearchDetails } from '../_models';
import { Injectable } from '@angular/core';
import { isNumber, toInteger, padNumber } from '@ng-bootstrap/ng-bootstrap/util/util';
import { MetadataModel } from '../_models/MetadataModel';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';
import { FormControl, NgForm, FormBuilder } from '@angular/forms';
import {DocumentModel} from '../_models/DocumentModel';


 @NgModule ({
    imports: [OwlDateTimeModule, OwlNativeDateTimeModule, NgbModule.forRoot()],
})

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css', './picker.min.css', ],
  providers: [
    {provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter}
   ]
})

@Injectable()
export class SearchComponent implements OnInit {

  public searchData:  Array<object> = [];
  submitted = false;
  searchModel: SearchDetails = new SearchDetails();
  metadata: MetadataModel = new MetadataModel();
    documentModel: DocumentModel = new DocumentModel();

  constructor(private _invoiceService: InvoiceService) {
  }
  ngOnInit() {

  }
   closeCallout(){
     console.log('Inside Close');
   document.getElementById("callout").style.display='none';
    document.getElementById("myImage").style.opacity = "1"; 
   }
 getDocumentDetails(invoiceData) {
    document.getElementById("myImage").style.opacity = "0.5";
   
    console.log(invoiceData.legacyDocId);

    this.documentModel.docType = "invoices";
    this.documentModel.docId = invoiceData.docId;
    this.documentModel.legacyDocId = invoiceData.legacyDocId;

    this._invoiceService.getDocumentProperties(this.documentModel).subscribe((data: Array<object>) => {

      console.log(data['metadataList']);

      document.getElementById('callout').style.display = 'inline-block';

      document.getElementById('docName').innerText = data['metadataList'].docName;
      document.getElementById('docTitle').innerText = data['metadataList'].docTitle;
      document.getElementById('ownerName').innerText = data['metadataList'].ownerName;
      document.getElementById('versionNum').innerText = data['metadataList'].versionNum;
      document.getElementById('creator').innerText = data['metadataList'].creator;
      document.getElementById('billingId').innerText = data['metadataList'].billingId;
      document.getElementById('modifyDate').innerText = data['metadataList'].modifyDate;
      document.getElementById('modifier').innerText = data['metadataList'].modifier;
      document.getElementById('retentionDate').innerText = data['metadataList'].retentionDate;
      document.getElementById('invoiceDate').innerText = data['metadataList'].invoiceDate;
      document.getElementById('customerName').innerText = data['metadataList'].customerName;
      document.getElementById('legacyDocId').innerText = data['metadataList'].legacyDocId;
      document.getElementById('transactionIdm').innerText = data['metadataList'].transactionIdm;
      document.getElementById('invoiceNumber').innerText = data['metadataList'].invoiceNumber;
      document.getElementById('createDate').innerText = data['metadataList'].createDate;





    });
  }

   
   search(userForm: NgForm) {
     console.log(userForm);
   }
   

public  getSearchData() {

        this.searchModel.metadata = this.metadata;
        this._invoiceService.searchInvoices(this.searchModel).subscribe((data:  Array<object>) => {
        this.searchData  =  data['metadataList'];
        console.log('entered');
        // console.log(data);
        // console.log(this.searchModel);
            console.log(this.searchData);

    });
}

formatDate(dateObj) {
if (dateObj['year'] === undefined) {
  return undefined;
} else {
const dueYear = dateObj['year'];
const dueMonth = dateObj['month'];
const dueDay = dateObj['day'];


return dueYear  + '/' + dueMonth + '/' +  dueDay;
}
}

onSubmit() {

if (this.metadata.dueDate !== undefined && this.metadata.dueDate !== '') {
this.metadata.dueDate = this.formatDate(this.metadata.dueDate);
} else  {
  this.metadata.dueDate = undefined;

}
if (this.metadata.fileDate !== undefined && this.metadata.fileDate !== '') {
    this.metadata.fileDate = this.formatDate(this.metadata.fileDate);
}  else  {
  this.metadata.fileDate = undefined;
 
}
 if (this.metadata.folder !== undefined && this.metadata.folder !== '') {
    this.metadata.folder = this.formatDate(this.metadata.folder);
}  else  {
  this.metadata.folder = undefined;
   
}
if (this.metadata.interestYear !== undefined && this.metadata.interestYear !== '') {
  this.metadata.interestYear = this.formatDate(this.metadata.interestYear);
} else  {
  this.metadata.interestYear = undefined;
  
}
if (this.metadata.accountNumber !== undefined && this.metadata.accountNumber !== '') {
  this.metadata.accountNumber = this.metadata.accountNumber;
} else  {
  this.metadata.accountNumber = undefined;
  
}
if (this.metadata.fileName !== undefined && this.metadata.fileName !== '') {
  this.metadata.fileName = this.metadata.fileName;
} else  {
  this.metadata.fileName = undefined;

}
if (this.metadata.billingId !== undefined && this.metadata.billingId !== '') {
  this.metadata.billingId = this.metadata.billingId;
} else  {
  this.metadata.billingId = undefined;
  
}
if (this.metadata.documentTitle !== undefined && this.metadata.documentTitle !== '') {
  this.metadata.documentTitle = this.metadata.documentTitle;
} else  {
  this.metadata.documentTitle = undefined;

}
if (this.metadata.documentName !== undefined && this.metadata.documentName !== '') {
  this.metadata.documentName = this.metadata.documentName;
} else  {
  this.metadata.documentName = undefined;
 
}
if (this.metadata.transactionIdm !== undefined && this.metadata.transactionIdm !== '') {
  this.metadata.transactionIdm = this.metadata.transactionIdm;
} else  {
  this.metadata.transactionIdm = undefined;

}
if (this.metadata.customerNumber !== undefined && this.metadata.customerNumber !== '') {
  this.metadata.customerNumber = this.metadata.customerNumber;
} else  {
  this.metadata.customerNumber = undefined;

}
if (this.metadata.invoiceType !== undefined && this.metadata.invoiceType !== '') {
  this.metadata.invoiceType = this.metadata.invoiceType;
} else  {
  this.metadata.invoiceType = undefined;
  
}
if (this.metadata.fileNetGuid !== undefined && this.metadata.fileNetGuid !== '') {
  this.metadata.fileNetGuid = this.metadata.fileNetGuid;
} else  {
  this.metadata.fileNetGuid = undefined;

}
if (this.metadata.invoiceFolder !== undefined && this.metadata.invoiceFolder !== '') {
  this.metadata.invoiceFolder = this.metadata.invoiceFolder;
} else  {
  this.metadata.invoiceFolder = undefined;

}
    this.getSearchData();
    console.log(this.getSearchData());
    document.getElementById('displaytable').style.display = 'inline-table';
    return true;
  }



}
