import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountDocumentUploadComponent } from './account-document-upload.component';

describe('AccountDocumentUploadComponent', () => {
  let component: AccountDocumentUploadComponent;
  let fixture: ComponentFixture<AccountDocumentUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountDocumentUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountDocumentUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
