import { CorptaxModel } from '../_models';
import { UploadModel } from '../_models/uploadModel';
import { CorporationDropDown } from '../_models/corporationDropDown';
import { CountyDropDown } from '../_models/countyDropDown';
import { StatesDropDown } from '../_models/statesDropDown';
import { ActionsDropDown } from '../_models/actionsDropDown';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbDateParserFormatter, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';

import { NgbModal, ModalDismissReasons, NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FileSelectDirective, FileUploader } from 'ng2-file-upload';
import { FormControl, NgForm, FormBuilder, FormGroup, Validators } from '@angular/forms';
// import * as Collections from 'typescript-collections';
@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})


export class UploadComponent implements OnInit {
  public formGroup: FormGroup;

  constructor(private modalService: NgbModal, private _fb: FormBuilder) {
    this.initForm();
  }

  uploadArray = [];
  @ViewChild('content') public modalReference: NgbModalRef;
  closeResult: string;

  uploadData = [];


  // uploadArray= new Collections.Set<UploadModel>();
  file = [];
  // uploadModel: UploadModel = new UploadModel();
  corptaxModel: CorptaxModel = new CorptaxModel();
  corporations: CorporationDropDown[] = [

    { id: 0, name: '0-Unknown' },
    { id: 1, name: '001-GENERAL ELECTRIC CAPITAL CORPORATION' },
    { id: 2, name: '002-GENERAL ELECTRIC CREDIT CORP OF GA' },
    { id: 3, name: '003-GENERAL ELECTRIC CREDIT AND LEASING CORP' },
    { id: 4, name: '013-GENERAL ELECTRIC CREDIT CORP OF TENNESSE' },
    { id: 5, name: '014-GENERAL ELECTRIC CREDIT EQUITIES INC' },
    { id: 6, name: '016-FULL SERVICE LEASING CORPORATION' },

  ];
  states: StatesDropDown[] = [
    { id: 0, name: 'Chicago' },
    { id: 1, name: 'Texas' },
    { id: 2, name: 'New Jersey' },
    { id: 3, name: 'New York' },
    { id: 4, name: 'Florida' },
    { id: 5, name: 'Illinois' },
    { id: 6, name: 'Minnesota' },

  ];

  counties: CountyDropDown[];
  getCounty(Event) {
    console.log(Event.target.value);
    var state: string = Event.target.value;
    switch (state) {
      case "New Jersey": {
        this.counties = [
          { id: 0, name: 'Atlantic county' },
          { id: 1, name: 'Bergen County' },
          { id: 2, name: 'Cape May County' },
        ];
        break;
      }
      case "Chicago": {
        this.counties = [
          { id: 0, name: 'Cook County' },
          { id: 1, name: 'Lake County' },
          { id: 2, name: 'Newton County' },
        ];
        break;
      }
      case "Texas": {
        this.counties = [
          { id: 0, name: 'Anderson County' },
          { id: 1, name: 'Bailey County' },
          { id: 2, name: 'Carson County' },
        ];
        break;
      }
      case "New York": {
        this.counties = [
          { id: 0, name: 'Albany County' },
          { id: 1, name: 'Bronx County' },
          { id: 2, name: 'Chemung County' },
        ];
        break;
      }
      case "Florida": {
        this.counties = [
          { id: 0, name: 'Baker County' },
          { id: 1, name: 'Bay County' },
          { id: 2, name: 'Citrus County' },
        ];
        break;
      }
      case "Illinois": {
        this.counties = [
          { id: 0, name: 'Will County' },
          { id: 1, name: 'DuPage County' },
          { id: 2, name: 'Cook County' },
        ];
        break;
      }
      case "Minnesota": {
        this.counties = [
          { id: 0, name: 'Anoka County' },
          { id: 1, name: 'Becker County' },
          { id: 2, name: 'Brown County' },
        ];
        break;
      }
      default: {
        this.counties = [
        ];
        break;
      }

    }
  }


  ngOnInit() {
  }
  private initForm() {
    this.formGroup = this._fb.group({
      name: this._fb.control('', [Validators.required])
    })
  }

  

  

  open(content) {
    this.modalReference = this.modalService.open(content);
    this.modalReference.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }



  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }


  uploadTable(Event) {
    this.file = Event.target.files;
    for (let i = 0; i < this.file.length; i++) {
      const uploadModel = new UploadModel();
      uploadModel.fileName = this.file[i].name;
      this.uploadArray[i] = uploadModel;
    }
    this.uploadData = Array.of(this.uploadArray);
    document.getElementById('displayTable').style.display = 'inline-block';
  }

  upload(userForm: NgForm) {
    if (userForm.valid) {

    }
    console.log(userForm._directives);
  }
  accept() {
    document.getElementById('display').style.display = 'block';
    this.modalReference.close();
  }
  close() {
    this.modalReference.close();
  }
}



