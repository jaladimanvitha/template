﻿import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http/src/response';
import { ApiToken } from './ApiToken';
import { UserData } from './_models/userdata.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  private admin: boolean;

  constructor(
    
  ){
    this.admin = false;
  }
  
  ngOnInit() {

  }

  private makeApiCall() {
    
  }

  public isAdmin(): boolean {
    if(this.admin) {
      return true;
    }
    return false;
  }

  corptax() {
    if (document.getElementById('corptaxDropdown').style.display === 'none') {
      document.getElementById('corptaxDropdown').style.display = 'inline';
    } else {
      document.getElementById('corptaxDropdown').style.display = 'none';
    }
  }
  ifLeasing() {
    if (document.getElementById('ifLeasingDropdown').style.display === 'none') {
      document.getElementById('ifLeasingDropdown').style.display = 'inline';
    } else {
      document.getElementById('ifLeasingDropdown').style.display = 'none';
    }
  }
  lockBox() {
    if (document.getElementById('lockBoxDropdown').style.display === 'none') {
      document.getElementById('lockBoxDropdown').style.display = 'inline';
    } else {
      document.getElementById('lockBoxDropdown').style.display = 'none';
    }
  }
  reports() {
    if (document.getElementById('reportsDropdown').style.display === 'none') {
      document.getElementById('reportsDropdown').style.display = 'inline';
    } else {
      document.getElementById('reportsDropdown').style.display = 'none';
    }
  }
  invoice() {
    if (document.getElementById('invoiceDropdown').style.display === 'none') {
      document.getElementById('invoiceDropdown').style.display = 'inline';
    } else {
      document.getElementById('invoiceDropdown').style.display = 'none';
    }
  }
  deeplink() {
    if (document.getElementById('deeplinkDropDown').style.display === 'none') {
      document.getElementById('deeplinkDropDown').style.display = 'inline';
    } else {
      document.getElementById('deeplinkDropDown').style.display = 'none';
    }
  }

  // Code Below is for SAML Integration.
  /*
    title = 'app';

    apiToken: string;

    showUnauthorizedMessage: boolean;

    apiResult;

    logoutSuccess: boolean;

    constructor(private httpClient: HttpClient) {
    }

    ngOnInit(): void {

      this.httpClient.get('service/auth/token')
        .subscribe(
          r => this.handleTokenSuccess(r as ApiToken),
          error => this.handleTokenError(error));

    }

    handleTokenSuccess(apiToken: ApiToken) {
      this.apiToken = apiToken.token;
      localStorage.setItem('apiToken', apiToken.token);
      this.callApi();
    }

    handleTokenError(error: HttpErrorResponse) {

      if (error.status === 401) {
        this.showUnauthorizedMessage = true;
        setTimeout(() => window.location.replace('http://localhost:8080/saml/login'), 4000);
      }
    }

    callApi() {
      const apiToken = localStorage.getItem('apiToken');

      this.httpClient.get('/service/api/mycontroller/', {
        headers: {
          'x-auth-token': apiToken
        }
      }).subscribe(r => this.apiResult = JSON.stringify(r));
    }

    logout() {
      console.log('logout');
      localStorage.removeItem('apiToken');
      this.httpClient.get('service/saml/logout').subscribe(() => this.logoutSuccess = true);
    }
    */

}
