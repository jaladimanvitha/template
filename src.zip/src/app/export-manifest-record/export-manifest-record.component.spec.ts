import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportManifestRecordComponent } from './export-manifest-record.component';

describe('ExportManifestRecordComponent', () => {
  let component: ExportManifestRecordComponent;
  let fixture: ComponentFixture<ExportManifestRecordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExportManifestRecordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportManifestRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
