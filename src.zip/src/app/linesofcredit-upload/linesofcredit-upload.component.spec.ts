import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinesofcreditUploadComponent } from './linesofcredit-upload.component';

describe('LinesofcreditUploadComponent', () => {
  let component: LinesofcreditUploadComponent;
  let fixture: ComponentFixture<LinesofcreditUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinesofcreditUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinesofcreditUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
