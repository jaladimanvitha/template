export class LockboxModel {

   
    public abaNumber: string;
    public batchitem: string;
    public batchnumber: string;
    public imagetype: string;
    public checkamount: string;
    public depositdate: string;
    public invoicenumber: string;
    public totalamount: string;
    public checknumber: string;
    public currentamount: string;
    public lockboxnumber: string;
    public checklast8: string;
    public amountschedulable: string;
    public checkingAccNumber: string;
    public transactionUid: string;
    public tid: string;
    public filenetGuid: string;
    public name: string;
    public title: string;

}
