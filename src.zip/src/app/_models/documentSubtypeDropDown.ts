export class DocumentSubtypeDropDown {

  public id: number;
  public name: string;
}
