export class SubtypeIdDropDown {

  public id: number;
  public name: string;
}
