export class CorporationDropDown {

  public id: number;
  public name: string;
}
