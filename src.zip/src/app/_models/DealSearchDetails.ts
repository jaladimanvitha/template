import { DealsearchModel } from './DealsearchModel';


export class DealSearchDetails {

    public docType = 'Industrial Finance';
    public dealSearchModel: DealsearchModel;

}
