export class DocumentModel {

    public docType: string;
    public legacyDocId: string;
    public docId: string;

}