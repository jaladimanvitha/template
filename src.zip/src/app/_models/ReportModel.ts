export class ReportModel {

    public keywords: string;
    public reportid: string;
    public reportdate: string;
    public reportrundate: string;
    public jobnumber: string;
    public fileNetGuid: string;
    public name: string;
    public title: string;
    public creator: string;
    public modifier: string;
    public modifieddate: string;


}
