export class DealsearchModel {

  public partyNumber: string;
  public entityType: string;
  public actions: string;
  public partyName: string;
  public sfdcAccountId: string;
  public sfdcAccountName: string;
  public sfdcOpportunityId: string;
  public lineOfCreditNumber: string;
  public lwContractSequenceNumber: string;
  public documentSubType: string;
  public contractDealtype: string;
  public creator: string;
  public modifier: string;
  public modifiedDateFrom: number;
  public modifiedDateTo: number;
  public retentialDateFrom: number;
  public retentialDateTo: number;
  public status: string;
  public welcomePackage: string;
  public syndicatePackage: string;
  public partyDealType: string;
  public source: string;
  public lineOfBusinessCode: string;
  public legalEntityName: string;
  public fileNetdockey: string;
  public fileNetGuid: string;
  public name: string;
  public title: string;


}
