export class UploadTableModel{
  
  public fileName: string;
  public amount: string;
  
}
