export class CountyDropDown {

  public id: number;
  public name: string;
}
