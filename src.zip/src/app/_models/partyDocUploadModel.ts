export class PartyDocUploadModel {

    public partyNumber5: string;
    public partyName5: string;
    public partyDealType5: string;
    
}
