import { ManifestModel } from './ManifestModel';


export class ManifestDetails {

    public docType = 'manifest';
    public manifestModel: ManifestModel;

}
