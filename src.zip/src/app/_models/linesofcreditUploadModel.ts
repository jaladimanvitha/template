export class LinesofcreditUploadModel {

    public partyNumber3: string;
    public partyName3: string;
    public sfdcAccountId3: string;
    public sfdcopportunityId3: string;
    public lineofcreditNumber3: string;
    public lineofBusinessCode3: string;
    public legalEntityName3: string;
  
    
}
