export class ActionsDropDown {

  public id: number;
  public name: string;
}
