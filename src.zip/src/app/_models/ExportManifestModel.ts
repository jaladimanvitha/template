import { ShippingMethodDropDown } from './shippingMethodDropDown';


export class ExportManifestModel {

  public senderName: string;
  public senderBusiness: string;
  public shippingMethod: string;
  public storerNum: string;
  public trackingNum: string;
  public businessLocation: string;
  public createdBy: string;
  public modifiedBy: string;
  public creationDateFrom: string;
  public creationDateTo : string;
  public modifiedDateFrom: string;
  public modifiedDateTo: string;

}
