export class GecDocumentSearchModel {

  public categoryId: string;
  public typeId: string;
  public subTypeId: string;
  public quoteId: string;
  public classId: string;
  public customerId: string;
  public contractId: string;
  public sumId: string;
  public transactionId: string;
  public creditId: string;
  public gecDockey: string;
  public takedownIdm: string;
  public submittalIdm: string;
  public platform: number;
  public referenceCustId: number;
  public customerEligibility: number;
  public program: number;
  public envelopeId: string;
  public referenceId: string;
  public srNumber: number;
  public hold: string;
  public documentDate: string;
  public programSegment: string;
  public scanDate: string;
  public fileNetGuid: string;
  public name: string;
  public title: string;
  public creator: string;
  public modifier: string;
  public modifiedDate: string;

}
