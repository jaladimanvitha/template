export class PartyDealDropDown {

  public id: number;
  public name: string;
}
