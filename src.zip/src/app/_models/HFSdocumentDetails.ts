import { HFSdocumentModel } from './HFSdocumentModel';


export class HFSdocumentDetails {

    public docType = 'Hfs';
    public hfsModel: HFSdocumentModel;

}
