export class ContractUploadModel {

    public partyNumber2: string;
    public partyName2: string;
    public contractDealtype: string;
    public sfdcAccountId2: string;
    public sfdcopportunityId2: string;
    public lineofcreditNumber2: string;
    public lwSeqNumber2: string;
    public contractDealtype2: string;
    public lineofBusinessCode2: string;
    public legalEntityName2: string;
    
}
