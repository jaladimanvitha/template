export class SourceDropDown {

  public id: number;
  public name: string;
}
