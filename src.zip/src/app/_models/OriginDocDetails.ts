import { OriginDocSearchModel } from './originDocSearchModel';


export class OriginDocDetails {

    public docType = 'originations';
    public originDoc: OriginDocSearchModel;

}
