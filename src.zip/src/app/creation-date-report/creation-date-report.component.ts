import { Component, OnInit } from '@angular/core';
import { ObjectStoreDropdown } from '../_models/ObjectStoreDropdown';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';

@Component({
  selector: 'app-creation-date-report',
  templateUrl: './creation-date-report.component.html',
  styleUrls: ['./creation-date-report.component.css'],
  providers: [
    {provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter}
   ]
})
export class CreationDateReportComponent implements OnInit {
  public searchData:  Array<object> = [];
  constructor() { }
  objectstore: ObjectStoreDropdown = new ObjectStoreDropdown();
  objectStores: ObjectStoreDropdown[] = [

    { id: 0, name: 'Lockbox Document'},
    { id: 1, name: 'Corptax Document'},
    { id: 2, name: 'GE Reports Document'},
    { id: 3, name: 'Invoice Document'},
    { id: 4, name: 'GEC Document'},
    { id: 5, name: 'HFS Document'},
    { id: 6, name: 'Origin Document'},
    { id: 7, name: 'All Document'}

  ];
  ngOnInit() {
  }
  onSubmit() {

    document.getElementById('displaytable').style.display = 'inline-table';
    return true;
  }
}
