import { MetadataModel } from '../_models/MetadataModel';
import { SearchDetails } from '../_models';
import { InvoiceService } from '../_services';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { OnInit } from '@angular/core';

@Injectable({
providedIn:  'root'
})
export class SearchService implements OnInit {


  public searchData:  Array<object> = [];
  metadata: MetadataModel = new MetadataModel();
  searchModel: SearchDetails = new SearchDetails();

constructor(private _invoiceService: InvoiceService) {
  }

ngOnInit() {

  }
metadataIntialization(metadata) {

if (this.metadata.dueDate !== undefined && this.metadata.dueDate !== '') {
 this.metadata.dueDate = this.formatDate(this.metadata.dueDate);
} else  {
  this.metadata.dueDate = undefined;
}
if (this.metadata.fileDate !== undefined && this.metadata.fileDate !== '') {
    this.metadata.fileDate = this.formatDate(this.metadata.fileDate);
}  else  {
  this.metadata.fileDate = undefined;
}
if (this.metadata.interestYear !== undefined && this.metadata.interestYear !== '') {
  this.metadata.interestYear = this.formatDate(this.metadata.interestYear);
} else  {
  this.metadata.interestYear = undefined;
}
if (this.metadata.accountNumber !== undefined && this.metadata.accountNumber !== '') {
  this.metadata.accountNumber = this.metadata.accountNumber;
} else  {
  this.metadata.accountNumber = undefined;
}
if (this.metadata.fileName !== undefined && this.metadata.fileName !== '') {
  this.metadata.fileName = this.metadata.fileName;
} else  {
  this.metadata.fileName = undefined;
}
if (this.metadata.billingId !== undefined && this.metadata.billingId !== '') {
  this.metadata.billingId = this.metadata.billingId;
} else  {
  this.metadata.billingId = undefined;
}
if (this.metadata.documentTitle !== undefined && this.metadata.documentTitle !== '') {
  this.metadata.documentTitle = this.metadata.documentTitle;
} else  {
  this.metadata.documentTitle = undefined;
}
if (this.metadata.documentName !== undefined && this.metadata.documentName !== '') {
  this.metadata.documentName = this.metadata.documentName;
} else  {
  this.metadata.documentName = undefined;
}
if (this.metadata.transactionIdm !== undefined && this.metadata.transactionIdm !== '') {
  this.metadata.transactionIdm = this.metadata.transactionIdm;
} else  {
  this.metadata.transactionIdm = undefined;

}
if (this.metadata.customerNumber !== undefined && this.metadata.customerNumber !== '') {
  this.metadata.customerNumber = this.metadata.customerNumber;
} else  {
  this.metadata.customerNumber = undefined;
}
if (this.metadata.invoiceType !== undefined && this.metadata.invoiceType !== '') {
  this.metadata.invoiceType = this.metadata.invoiceType;
} else  {
  this.metadata.invoiceType = undefined;
}
if (this.metadata.fileNetGuid !== undefined && this.metadata.fileNetGuid !== '') {
  this.metadata.fileNetGuid = this.metadata.fileNetGuid;
} else  {
  this.metadata.fileNetGuid = undefined;
}
if (this.metadata.invoiceFolder !== undefined && this.metadata.invoiceFolder !== '') {
  this.metadata.invoiceFolder = this.metadata.invoiceFolder;
} else  {
  this.metadata.invoiceFolder = undefined;
}
if (this.metadata.invoiceFolder !== undefined && this.metadata.invoiceFolder !== '') {
  this.metadata.invoiceFolder = this.metadata.invoiceFolder;
} else  {
  this.metadata.invoiceFolder = undefined;
}
if (this.metadata.folder !== undefined && this.metadata.folder !== '') {
  this.metadata.folder = this.metadata.folder;
} else  {
  this.metadata.folder = undefined;
}

return this.metadata;
}

formatDate(dateObj) {
if (dateObj['year'] === undefined) {
  return undefined;
} else {
const dueYear = dateObj['year'];
const dueMonth = dateObj['month'];
const dueDay = dateObj['day'];

return dueYear  + '/' + dueMonth + '/' +  dueDay;
}
}

}
