import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
providedIn:  'root'
})


export class InvoiceService {
API_URL  =  'http://localhost:8080';




    constructor(private httpClient: HttpClient) { }

searchInvoices(searchModel: Object): Observable<Object> {

    return this.httpClient.post(`http://localhost:9090/api/secure/searchMetadata`, searchModel,
    
    );

}
  getDocumentProperties(documentModel: Object): Observable<Object> {
  
  return this.httpClient.post(`http://localhost:9090/api/secure/documentProperties`, documentModel);
  
}

searchCorptax(searchModel: Object): Observable<Object> {

    return this.httpClient.post(`${this.API_URL}/search/corptax`, searchModel);

}

searchIndustrialFinancialDeal(searchModel: Object): Observable<Object> {

    return this.httpClient.post(`${this.API_URL}/search/dealSearch`, searchModel);

}

searchGecDocument(searchModel: Object): Observable<Object> {

    return this.httpClient.post(`${this.API_URL}/search/gecDocument`, searchModel);

}
searchGeReports(searchModel: Object): Observable<Object> {

    return this.httpClient.post(`${this.API_URL}/search/gereports`, searchModel);

}
searchHfsDocument(searchModel: Object): Observable<Object> {

    return this.httpClient.post(`${this.API_URL}/search/hfsDocSearch`, searchModel);

}
searchManifest(searchModel: Object): Observable<Object> {

    return this.httpClient.post(`${this.API_URL}/search/manifest`, searchModel);

}

searchOriginDocSearch(searchModel: Object): Observable<Object> {

    return this.httpClient.post(`${this.API_URL}/search/originDocSearch`, searchModel);

}

searchLockbox(searchModel: Object): Observable<Object> {

    return this.httpClient.post(`http://localhost:9090/api/secure/searchMetadata`, searchModel);

}

}

