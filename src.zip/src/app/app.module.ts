﻿import { Component, NgModule, VERSION, ViewChild } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import {BrowserAnimationsModule, NoopAnimationsModule} from '@angular/platform-browser/animations';
import { FileSelectDirective } from 'ng2-file-upload';
import { AppComponent } from './app.component';
import { routing } from './app.routing';
import { AlertService, InvoiceService , SearchService } from './_services';
import { HomeComponent } from './home';
import { SearchComponent } from './search/search.component';
import {DataTableModule} from 'angular-6-datatable';
 // import { DatePickerComponent } from "./search/datepicker.component";
import { NgDatepickerModule } from 'ng2-datepicker';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { CorptaxSearchComponent } from './corptax-search/corptax-search.component';
import { UploadComponent } from './upload/upload.component';
import { ReportsComponent } from './reports/reports.component';
import { LockboxComponent } from './lockbox/lockbox.component';
import { OriginationDocumentSearchComponent } from './origination-document-search/origination-document-search.component';
import { CreationDateReportComponent } from './creation-date-report/creation-date-report.component';
import { ManifestComponent } from './manifest/manifest.component';
import { HFSdocumentComponent } from './hfsdocument/hfsdocument.component';
import { DealsearchComponent } from './dealsearch/dealsearch.component';
import { GecDocumentSearchComponent } from './gec-document/gecdocumentsearch.component';
import { SampleComponent } from './sample/sample.component';
import { ExportManifestRecordComponent } from './export-manifest-record/export-manifest-record.component';
import { PartyDocumentUploadComponent } from './party-document-upload/party-document-upload.component';
import { AccountDocumentUploadComponent } from './account-document-upload/account-document-upload.component';
import { OpportunityDocumentUploadComponent } from './opportunity-document-upload/opportunity-document-upload.component';
import { LinesofcreditUploadComponent } from './linesofcredit-upload/linesofcredit-upload.component';;
import { ContractUploadComponent } from './contract-upload/contract-upload.component'

@NgModule({
    imports: [
        BrowserModule,
        OwlDateTimeModule,
        OwlNativeDateTimeModule,
        NoopAnimationsModule,
        ReactiveFormsModule,
        HttpClientModule,
        routing,
        FormsModule,
        HttpModule,
        DataTableModule,
        NgDatepickerModule,
        NgbModule.forRoot()

    ],
    declarations: [
        AppComponent,
        HomeComponent,
        SearchComponent,
        CorptaxSearchComponent,
        FileSelectDirective,
        UploadComponent ,
        ReportsComponent,
        LockboxComponent,
        OriginationDocumentSearchComponent ,
        CreationDateReportComponent,
        ManifestComponent ,
        HFSdocumentComponent,
        DealsearchComponent,
        GecDocumentSearchComponent,
        SampleComponent,
		ExportManifestRecordComponent,
		PartyDocumentUploadComponent,
		AccountDocumentUploadComponent ,
		OpportunityDocumentUploadComponent ,
		LinesofcreditUploadComponent ,
		ContractUploadComponent        ],

    providers: [
        AlertService,
        InvoiceService,
        SearchService,
    ],
    bootstrap: [AppComponent]
})

export class AppModule {
}
