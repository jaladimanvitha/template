import { CorptaxModel, CorptaxDetails } from '../_models';
import { Component, OnInit } from '@angular/core';
import { CorporationDropDown } from '../_models/corporationDropDown';
import { CountyDropDown } from '../_models/countyDropDown';
import { StatesDropDown } from '../_models/statesDropDown';
import { InvoiceService } from '../_services';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';

@Component({
  selector: 'app-corptax-search',
  templateUrl: './corptax-search.component.html',
  styleUrls: ['./corptax-search.component.css'],
  providers: [
    {provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter}
   ]
})
export class CorptaxSearchComponent implements OnInit {


  corptaxModel: CorptaxModel = new CorptaxModel();
  corporations: CorporationDropDown[] = [
    { id: 0, name: '0-Unknown' },
    { id: 1, name: '001-GENERAL ELECTRIC CAPITAL CORPORATION' },
    { id: 2, name: '002-GENERAL ELECTRIC CREDIT CORP OF GA' },
    { id: 3, name: '003-GENERAL ELECTRIC CREDIT AND LEASING CORP' },
    { id: 4, name: '013-GENERAL ELECTRIC CREDIT CORP OF TENNESSE' },
    { id: 5, name: '014-GENERAL ELECTRIC CREDIT EQUITIES INC' },
    { id: 6, name: '016-FULL SERVICE LEASING CORPORATION' },

  ];
  states: StatesDropDown[] = [

    { id: 0, name: 'Texas' },
    { id: 1, name: 'New Jersey' },
    { id: 2, name: 'New York' },
    { id: 3, name: 'Florida' },
    { id: 4, name: 'Illinois' },
    { id: 5, name: 'Minnesota' },

  ];
  counties: CountyDropDown[];

  public searchData: Array<object> = [];
  submitted = false;
  searchModel: CorptaxDetails = new CorptaxDetails();
  metadata: CorptaxModel = new CorptaxModel();
  getCounty(Event) {
    console.log(Event.target.value);
    const state: string = Event.target.value;
    switch (state) {
      case 'New Jersey': {
        this.counties = [
          { id: 0, name: 'Atlantic county' },
          { id: 1, name: 'Bergen County' },
          { id: 2, name: 'Cape May County' },
        ];
        break;
      }

      case 'Texas': {
        this.counties = [
          { id: 0, name: 'Anderson County' },
          { id: 1, name: 'Bailey County' },
          { id: 2, name: 'Carson County' },
        ];
        break;
      }
      case 'New York': {
        this.counties = [
          { id: 0, name: 'Albany County' },
          { id: 1, name: 'Bronx County' },
          { id: 2, name: 'Chemung County' },
        ];
        break;
      }
      case 'Florida': {
        this.counties = [
          { id: 0, name: 'Baker County' },
          { id: 1, name: 'Bay County' },
          { id: 2, name: 'Citrus County' },
        ];
        break;
      }
      case 'Illinois': {
        this.counties = [
          { id: 0, name: 'Will County' },
          { id: 1, name: 'DuPage County' },
          { id: 2, name: 'Cook County' },
        ];
        break;
      }
      case 'Minnesota': {
        this.counties = [
          { id: 0, name: 'Anoka County' },
          { id: 1, name: 'Becker County' },
          { id: 2, name: 'Brown County' },
        ];
        break;
      }
      default: {
        this.counties = [
        ];
        break;
      }

    }
  }
  constructor(private _invoiceService: InvoiceService) { }

  ngOnInit() {
  }

  public getSearchData() {
    console.log(this.searchData);
      this._invoiceService.searchCorptax(this.searchModel).subscribe((data: Array<object>) => {
      this.searchData = data['metadataList'];
      console.log('entered');
      // console.log(data);
      // console.log(this.searchModel);
      console.log(this.searchData);

    });
  }
  onSubmit() {
    this.getSearchData();
    document.getElementById('displaytable').style.display = 'inline-table';
    return true;
  }

}
