import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorptaxSearchComponent } from './corptax-search.component';

describe('CorptaxSearchComponent', () => {
  let component: CorptaxSearchComponent;
  let fixture: ComponentFixture<CorptaxSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorptaxSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorptaxSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
