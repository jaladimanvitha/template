import { Component, OnInit } from '@angular/core';
import { ManifestModel } from '../_models/ManifestModel';
import { InvoiceService } from '../_services';
import { ManifestDetails } from '../_models/ManifestDetails';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';

@Component({
  selector: 'app-manifest',
  templateUrl: './manifest.component.html',
  styleUrls: ['./manifest.component.css'],
  providers: [
    {provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter}
   ]
})
export class ManifestComponent implements OnInit {
  manifest: ManifestModel = new ManifestModel();
  public searchData:  Array<object> = [];
  submitted = false;
  searchModel: ManifestDetails = new ManifestDetails();
  manifestModel: ManifestModel = new ManifestModel();
  constructor(private _invoiceService: InvoiceService) {
  }
  ngOnInit() {

  }

public  getSearchData() {

        this.searchModel.manifestModel = this.manifestModel;
        this._invoiceService.searchManifest(this.searchModel).subscribe((data:  Array<object>) => {
        this.searchData  =  data['metadataList'];
        console.log('entered');
        // console.log(data);
        // console.log(this.searchModel);
            console.log(this.searchData);

    });
}

  onSubmit() {
    this.getSearchData();
    document.getElementById('displaytable').style.display = 'inline-table';
    return true;
  }
}
