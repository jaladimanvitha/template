import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartyDocumentUploadComponent } from './party-document-upload.component';

describe('PartyDocumentUploadComponent', () => {
  let component: PartyDocumentUploadComponent;
  let fixture: ComponentFixture<PartyDocumentUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartyDocumentUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartyDocumentUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
